<!doctype html>
<html lang="en">
<head>
   <meta charset="utf-8" />
   <title>K-Project</title>
   <link rel="stylesheet" href="main.css" />

</head>
<body>

<div id="menu">
   <img id="button_intro" src="img/intro_clicked.png" onClick="scrollPage(0)"/>
   <img id="button_cause" src="img/cause.png" onClick="scrollPage(1000)"/>
   <img id="button_dday" src="img/dday.png" onClick="scrollPage(2000)"/>
   <img id="button_involved" src="img/involved.png" onClick="scrollPage(3000)"/>
</div>

<div id="intro">
   <center>
   <div id="movie_clip">
   </div>
   </center>
   <div id="count_downs">
       <div id="count_down1">
          <p id="day1"><font color="white">day</font></p>
          <p id="hr1"><font color="white">hr</font></p>
          <p id="min1"><font color="white">min</font></p>
          <p id="sec1"><font color="white">sec</font></p>
       </div>
	   <div id="count_down2">
	   </div>
   </div>
</div>

<div id="cause">
    <div id="cause_left">
	   <div id="cause_left_textbox">
	   </div>
	</div>
	<div id="cause_right">
	   <div id="cause_right_textbox">
	   </div>
	</div>
</div>

<div id="dday">
    <div id="dday_left">
	   <div id="dday_left_textbox">
       </div>
	</div>
	<div id="dday_right">
	   <div id="dday_right_textbox">
	   </div>
	</div>
</div>

<div id="involved">
    <div id="involved_left">
	    <img id="button_twitter" src="img/twitter_logo.png"/>
	    <img id="button_facebook" src="img/facebook_logo.png"/>
		<div id="involved_left_textbox">
		</div>
	</div>
	<div id="involved_right">
	    <div id="involved_right_poster">
		   <h2><font color="white">POSTER</font></h2>
		</div>
	</div>   
</div>


<script type="text/javascript" src="http://code.jquery.com/jquery-latest.js" ></script>
<script type="text/javascript" src="main.js" ></script>
</body>
</html>